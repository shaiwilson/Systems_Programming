#ifndef HEADER_FILE
#define HEADER_FILE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "read.c"
#include "print.c"

#define MAXLEN 100 /* max char of quote */
#define MAXENTRY 50 /* max num of quote */

#endif